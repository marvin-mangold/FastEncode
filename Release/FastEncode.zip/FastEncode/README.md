# DatFormat
kleine Anwendung zum umwandeln eines Zahlenformats
* Hex
* Bin
* Dec
* ASCII
