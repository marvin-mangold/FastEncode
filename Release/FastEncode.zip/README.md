# FastEncode
- FastEncode is a Software to encode from (Hex, Bin, Dec, ASCII) to (Hex, Bin, Dec, ASCII)
- by pressing the startbutton the live encoding is active
- to copy the output you need to stop the live encoding

![Example01](https://user-images.githubusercontent.com/10088323/130139209-24f25b83-02f6-479e-a35a-929d56060154.jpg)

![Example02](https://user-images.githubusercontent.com/10088323/130139211-753ddda8-f8f9-48b3-bed5-ddcca8eb2cc8.JPG)

![Example03](https://user-images.githubusercontent.com/10088323/130139218-5b42e2b7-8005-4b1d-a73f-90f238dd2151.JPG)

![Example04](https://user-images.githubusercontent.com/10088323/130139219-43674e3f-8d11-482f-a7c4-b44d5237ef25.JPG)
